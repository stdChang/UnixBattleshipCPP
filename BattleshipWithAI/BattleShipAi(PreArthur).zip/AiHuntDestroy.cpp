//
// Created by steve on 5/27/2021.
//

#include "AiHuntDestroy.h"
BattleShip::AiHunter::AiHunter(std::map<char, int> ship_list) : AiRandom(ship_list) {
    AI_type = 3;
}

void BattleShip::AiHunter::PrioritizeThisArea(int r, int c, BattleShip::Board AiFiringBoard) {
    std::pair<int, int> coord;
    if (r >= 0 && r < AiFiringBoard.num_rows && (c - 1) >= 0 && (c - 1) < AiFiringBoard.num_columns && AiFiringBoard.AtCoord(r, c - 1) == '*') {
        coord.first = r;
        coord.second = c - 1;
        PriorityPlacesToShoot.push_back(coord);
    }
    if (r - 1 >= 0 && r - 1 < AiFiringBoard.num_rows && c >= 0 && c < AiFiringBoard.num_columns && AiFiringBoard.AtCoord(r - 1, c) == '*') {
        coord.first = r - 1;
        coord.second = c;
        PriorityPlacesToShoot.push_back(coord);
    }
    if (r >= 0 && r < AiFiringBoard.num_rows && (c + 1) >= 0 && (c + 1) < AiFiringBoard.num_columns && AiFiringBoard.AtCoord(r, c + 1) == '*') {
        coord.first = r;
        coord.second = c + 1;
        PriorityPlacesToShoot.push_back(coord);
    }
    if (r + 1 >= 0 && r + 1 < AiFiringBoard.num_rows && c >= 0 && c < AiFiringBoard.num_columns && AiFiringBoard.AtCoord(r + 1, c) == '*') {
        coord.first = r + 1;
        coord.second = c;
        PriorityPlacesToShoot.push_back(coord);
    }
    for (auto pair : PriorityPlacesToShoot) {
        auto itr = PlacesToShoot.begin();
        for(; itr < PlacesToShoot.end(); itr++) {
            if (pair == (*itr)) {
                PlacesToShoot.erase(itr);
            }
        }
    }
}

void BattleShip::AiHunter::GetPlaceToShoot(int& r, int& c) {
    if (!PriorityPlacesToShoot.empty()) {
        r = (PriorityPlacesToShoot.at(0)).first;
        c = (PriorityPlacesToShoot.at(0)).second;
        PriorityPlacesToShoot.erase(PriorityPlacesToShoot.begin());
    }
    else {
        //pick random element from place to shoot
        int index = 0;
        index = GetRandomIndex(generator);
        r = (PlacesToShoot.at(index)).first;
        c = (PlacesToShoot.at(index)).second;
        PlacesToShoot.erase(PlacesToShoot.begin() + index);
    }
}

